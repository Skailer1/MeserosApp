package com.example.meserosapp.data.enums;

public enum TipoDocumentoEnum
{
    PA,
    PE,
    CC,;

    private String name;

    public String getName() {
        return name;
    }
}
