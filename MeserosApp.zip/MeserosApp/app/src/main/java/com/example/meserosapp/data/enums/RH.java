package com.example.meserosapp.data.enums;

public enum RH
{
    A_POSITIVO,
    A_NEGATIVO,
    B_POSITIVO,
    B_NEGATIVO,
    O_POSITIVO,
    O_NEGATIVO,
    AB_POSTIVO,
    AB_NEGATIVO,;

    private String name;

    public String getName() {
        return name;
    }
}
