package com.example.meserosapp.data.enums;

public enum TipoEmpleadoEnum
{
    MESERO,
    COCINERO,
    CAJA,;

    private String name;

    public String getName() {
        return name;
    }
}
