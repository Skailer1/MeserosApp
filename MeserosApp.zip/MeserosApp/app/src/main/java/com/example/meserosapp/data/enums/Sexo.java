package com.example.meserosapp.data.enums;

public enum Sexo
{
    MACULINO,
    FEMENINO,
    OTRO,;

    private String name;

    public String getName() {
        return name;
    }
}
