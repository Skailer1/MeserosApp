package com.example.meserosapp.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.meserosapp.R;

public class DetallePedidoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_pedido);
    }
}
