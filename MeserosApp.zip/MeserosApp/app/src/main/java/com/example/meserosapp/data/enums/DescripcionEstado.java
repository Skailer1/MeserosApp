package com.example.meserosapp.data.enums;

public enum DescripcionEstado
{
    CREADO,
    COCINA,
    PREPARACION,
    ENTREGADO,;

    private String name;

    public String getName() {
        return name;
    }
}
